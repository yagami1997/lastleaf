# Lastleaf — Offline Recovery Toolkit

> When the original tool is gone, you can still open your own notes.

An independent, single-page decryptor for [Meld Encrypt](https://github.com/meld-cp/obsidian-encrypt) (Obsidian plugin). Algorithm constants reproduced 1:1 from the official source. Runs entirely in your browser — passwords and ciphertext never leave the page.

---

## Quick Start

**Double-click `index.html`.** That's it.

The page opens in your default browser under the `file://` protocol. Everything works offline:

- Decryption (uses the browser's built-in Web Crypto API — a W3C standard, no library needed)
- File upload, paste, password input, copy-to-clipboard
- The favicon and inline SVG logo

Web fonts (Fraunces, Inter, JetBrains Mono) will fall back to your system's serif/sans/mono fonts if you have no internet. The page remains fully functional and readable. If you want full visual fidelity, open it once while connected — the fonts will be cached by your browser.

---

## What's in this folder

```
lastleaf/
├── index.html          The tool itself. Open this.
├── favicon.svg         Vector icon (works at any size)
├── favicon-32.png      Fallback for older browsers
├── favicon-180.png     Apple touch icon (iOS home screen)
└── README.md           This file
```

No build step. No dependencies. No `package.json`. Open in any modern browser (Chrome / Firefox / Safari / Edge from ~2020 onwards).

---

## What it decrypts

Three formats, corresponding to Meld Encrypt's three internal algorithm versions:

| Version | Used by | Notes |
|---|---|---|
| **v0 · Obsolete** | Earliest inline encryption (`%%🔐 ... %%`) | Hardcoded IV, SHA-256 key derivation |
| **v1 · CryptoHelper** | Legacy whole-note + α inline (`%%🔐α ... %%`) | PBKDF2-SHA256, 1000 iterations |
| **v2 · CryptoHelper2304** | **Current default** — whole-note + β inline (`%%🔐β ... %%`) | PBKDF2-SHA512, 210000 iterations |

Whole-note files are JSON with `version` / `hint` / `encodedData` fields. Inline fragments are recognized by their prefix.

---

## Algorithm Reference

For future audit. Source: [`meld-cp/obsidian-encrypt`](https://github.com/meld-cp/obsidian-encrypt), `src/services/CryptoHelper*.ts`.

### v0 · Obsolete
```
prefix : 🔐 / %%🔐
key    = SHA-256(utf8(password))
iv     = [196,190,240,190,188,78,41,132,15,220,84,211]   // 12 bytes, hardcoded
cipher = AES-256-GCM(key, iv).encrypt(utf8(text))
output = base64(cipher)
```

### v1 · CryptoHelper
```
prefix : 🔐α / %%🔐α    ·    FileData "version": "1.0"
salt   = utf8("XHWnDAT6ehMVY2zD")              // 16 bytes, hardcoded
key    = PBKDF2-SHA256(utf8(password), salt, 1000) → AES-256
iv     = random(16)
cipher = AES-256-GCM(key, iv).encrypt(utf8(text))
output = base64(iv ‖ cipher)
```

### v2 · CryptoHelper2304 (current default)
```
prefix : 🔐β / %%🔐β    ·    FileData "version": "2.0"
salt   = random(16)
iv     = random(16)
key    = PBKDF2-SHA512(utf8(password), salt, 210000) → AES-256
cipher = AES-256-GCM(key, iv).encrypt(utf8(text))
output = base64(iv ‖ salt ‖ cipher)
```

The full decryption code is in the `<script>` tag of `index.html`. Open it in a text editor to audit.

---

## Verifying This Copy

This tool is meant to be used in emergencies, possibly years from now. Before trusting it with a real note:

1. **Open `index.html` in a text editor.** Confirm there is exactly one `<script>` block and one `<style>` block. No external script tags (only `<link>` tags for Google Fonts, which is CSS only).
2. **Search the file for `fetch`, `XMLHttpRequest`, and `WebSocket`** — none should appear in the script. The tool makes no outbound network calls of any kind.
3. **Run a known-good test:**
   - Create a test note in Obsidian with Meld Encrypt installed
   - Use a throwaway password (not your real one)
   - Close Obsidian
   - Open `index.html`, paste the encrypted JSON, enter the password
   - You should get the plaintext back

If step 3 succeeds, this copy of Lastleaf is functioning correctly.

---

## Recommended Storage

Keep copies of this folder in at least three places:

1. **Local disk** (e.g. `~/Documents/tools/lastleaf/`)
2. **A private Git repository** (audit trail + version history)
3. **The live site** at `lastleaf.encveil.dev`

Any one of the three is enough to recover your notes — but redundancy is the point.

---

## Threat Model

**This tool protects against:**
- The Meld Encrypt plugin becoming abandoned
- Obsidian breaking plugin compatibility in a future version
- Loss of access to your original setup (new machine, lost backups, etc.)

**This tool does NOT protect against:**
- A forgotten password — there is no recovery, by design
- Algorithm changes in future Meld Encrypt versions (v3+) — this tool would need to be updated
- Tampering with this HTML file — always verify the source if downloaded from an untrusted location

The Web Crypto API used here is part of every modern browser and a W3C standard. It is not going away.

---

## License & Attribution

Lastleaf is a third-party, independently-implemented decryptor. It is not affiliated with or endorsed by the Meld Encrypt project.

- Algorithm constants and decryption logic: reproduced from [`meld-cp/obsidian-encrypt`](https://github.com/meld-cp/obsidian-encrypt) (MIT License)
- This tool: released under the MIT License. Use freely.

Part of the [encveil.dev](https://encveil.dev) toolkit — one of many small tools against black-box power.

*Seek truth from facts.*

---

**Built:** May 23, 2026 at 20:51 PDT · Los Angeles
